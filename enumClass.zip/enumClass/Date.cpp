/*
 * Date.cpp
 *
 *  Created on: Mar 24, 2019
 *      Author: ultron
 */


#include "Date.h"
#include <iostream>
#include <string>


Date::Date(int day, int month, int year) : day(day), month(month), year(year){}

std::string Date::toString()const {
	std::string res;

	res = std::to_string(this->day) +
			'.' + std::to_string(month) +
			'.' + std::to_string(year);
	return res;
}

bool Date::isEqual(const Date& second)const {
	return this->day == second.day && this->month==second.month && this->year==second.year; //ASK WHY IS THIS POSSIBLE
}

Date& Date::operator++(){
    this->day++;
    if(this->day > this->months[this->month-1]) {
        this->month++;
        this->day = 1;
        if (this->month > 12) {
            this->year++;
            this->month = 1;
        }
    }
    return *this;
}

const Date Date::operator++(int) {
    Date* res = this;
    this->day++;
    if(this->day > this->months[this->month-1]) {
        this->month++;
        this->day = 1;
        if (this->month > 12) {
            this->year++;
            this->month = 1;
        }
    }
    return *res;
}

#include <iostream>
#include "Huffman.h"

int main(int argc, char* argv[]) {
    Huffman h;
    std::string pathToFolder = "C:\\Users\\Elisey\\OneDrive\\Documents\\GitHub\\school\\huffmanCompression\\";
    std::string enc_filename = argv[2];
    std::string dec_filename = argv[2];
    std::string enc_filepath = pathToFolder + enc_filename;
    std::string dec_filepath = pathToFolder + dec_filename;
    if(argc<3)
        return 0;
    if(argv[1] == "c"){
        h.encode(enc_filepath, pathToFolder+"out.txt");
    } else if(argv[1] == "d"){
        h.decode(dec_filepath, pathToFolder+"out_d.txt");
    } else {
        std::cout << "Wrong first argument.\n";
    }


}
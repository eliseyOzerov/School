/*
 * naloga2_1PRG2.cpp
 *
 *  Created on: Mar 13, 2019
 *      Author: ultron
 *
 *      https://stackoverflow.com/questions/21204589/static-vs-instance-variables-difference
 *      http://heather.cs.ucdavis.edu/~matloff/classvars.html
 */

#include "Clothing.h"
#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

void clothingToString(vector<Clothing*> clothes){
	for(unsigned int i = 0; i<clothes.size(); i++){
		clothes[i]->print();
	}
}

double getClothingTotal(vector<Clothing*> clothes){
	double final = 0;
	for(unsigned int i = 0; i<clothes.size(); i++){
			final += clothes[i]->getTotalPrice();
		}

	return final;
}

int main(){

	std::vector<Clothing*> clothes;
	Clothing c;
	try{
        c.addClothing(clothes, 0, 98, "Clothing1", 0);
	} catch(exception &e){
	    std::cout << e.what();
	}
    try{
        c.addClothing(clothes, 0, 46, "Clothing1", -100);
    } catch(exception &e){
        std::cout << e.what();
    }

}



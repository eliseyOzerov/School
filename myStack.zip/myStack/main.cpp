#include <iostream>
#include "MyStack.h"

int main() {
    MyStack<int> i;
    MyStack<Date> d;
    i.push(10);
    i.push(20);
    i.toString();
    d.push(Date(10, 7, 2017));
    d.push(Date(20, 5, 2011));
    d.toString();
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
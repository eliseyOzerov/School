//
// Created by Elisey on 05/05/2019.
//

#include "Node.h"

Node::Node() {}
Node::Node(int value): value(value) {}
Node::~Node() {}
